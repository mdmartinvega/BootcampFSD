//Confirguramos la variable de entorno "PORT"
// para que asigne la existe o la 3000 si no existe

process.env.PORT = process.env.PORT || 3000;